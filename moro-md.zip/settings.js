

const fs = require("fs")
//aumto presence update
global.autoTyping = true //auto tying in gc (true to on, false to off)
global.autoRecord = false //auto recording (true to on, false to off)
global.autoblockmorroco = true //auto block 212 (true to on, false to off)
global.wlcm = true
global.autokickmorroco = false //auto kick 212 (true to on, false to off) 
global.antispam = false//auto kick spammer (true to on, false to off)

//~~~~~~~~~~ Settings Saluran ~~~~~~~~~//
global.linkSaluran = "-"
global.idSaluran = "-@newsletter"
global.namaSaluran = "[ HAIRRI ]"
global.versi = "V.0.0.5"
global.namaOwner = "HAIRI"

global.xxc = "⇆ㅤ ㅤ◁ㅤ ❚❚ ㅤ▷ ㅤㅤ↻﻿"
global.qris = "https://qu.ax/hEmCn.jpg"
global.dana = "-"
global.ovo = "--"
global.gopay = "--"
// kalau gada, isi dengan "--"
//===============SETTING MENU==================\\
global.thumbnail = 'https://qu.ax/hEmCn.jpg'
global.ig = 'https://www.instagram.com/moro_0id?igsh=MTY4emR2M3o4c2F3aQ=='
global.yt = 'https://youtube.com/@moro_miniworld?si=zPVEsEiqtpetW5XH'
global.ttowner = 'https://www.tiktok.com/@moro_o?_t=ZS-8woUBcJY1vM&_r=1'
global.ownername = '🐺HAIRI🐺'
global.owner = ['6285810632092','6285143569870'] // SETTING JUGA DI FOLDER DATABASE 
global.ownernomer = '6285810632092','6285143569870'
global.socialm = 'GitHub: -'
global.location = 'Indonesia' 
global.versi = "5.0.5"
global.image = {
menu: "https://qu.ax/hEmCn.jpg", 
}
global.image = {
list: "https://qu.ax/hEmCn.jpg", 
}
global.thumb = 'https://qu.ax/hEmCn.jpg'
global.thumbnail = 'https://qu.ax/hEmCn.jpg'
//========================setting Payment=====================\\
global.nodana = '-' // KOSONG KAN JIKA TIDAK ADA
global.nogopay = '-' // KOSONG KAN JIKA TIDAK ADA 
global.noovo = '-' // KOSONG KAN JIKA TIDAK ADA
//==================setting Payment Name===========================\\
global.andana = '-' // KOSONG KAN JIKA TIDAK ADA
global.angopay = '-' // KOSONG KAN JIKA TIDAK ADA
global.anovo = '-' // KOSONG KAN JIKA TIDAK ADA
//==================setting bot===========================\\
global.botname = "MORO || BOT"
global.ownernumber = '6285810632092','6285143569870'
global.botnumber = '6285810632092','6285143569870'
global.ownername = 'HAIRI'
global.ownerNumber = ["6285810632092@s.whatsapp.net"]
global.ownerweb = "HAIRI"
global.websitex = "https://www.ryuushop.web.id"
global.wagc = "https://chat.whatsapp.com/EVlFx7jqjCB2dB7ovkY4Yx"
global.saluran = "https://chat.whatsapp.com/FZJwCjOKfXc07aFAakXtQc"
global.themeemoji = '🪀'
global.wm = "KINICH.ID"
global.botscript = 'Dah gede nyari sc 🗿🖕' //script link
global.packname = "Sticker By"
global.author = "\n\n\n\n\nCreate by  RyuuXiao"
global.creator = "6285143569870@s.whatsapp.net"
//======================== CPANEL FITUR ===========================\\
//===========================//
global.mess = {
   wait: "*_Sabar ya Kak, lagi masak mie instan...🍜_*",
   success: "Yeay! Berhasil Kak 🎉",
   on: "Udah Nyala nih! 🔥",
   off: "Udah Dimatiin 😴",
   query: {
       text: "Tulisannya mana, Kak? Aku kan gak bisa baca pikiran 😅",
       link: "Link-nya mana, Kak? Jangan pelit dong! 😜",
   },
   error: {
       fitur: "Oops! Ada yang rusak nih, Kak. Coba lapor ke developer biar bisa diperbaiki. 🙏",
   },
   only: {
       group: "Eh, Kak! Fitur ini cuma bisa dipake di grup, ya! 👥",
       private: "Fitur ini cuma buat chat pribadi, Kak. Jangan salah kamar 😏",
       owner: "Cuma buat si bos bot nih, Kak. Maaf ya 😬",
       admin: "Hanya bisa dipakai sama admin grup, Kak. Mungkin lain kali ya 😉",
       badmin: "Waduh! Bot-nya belum jadi admin grup nih. Tolong kasih jabatan dulu, Kak 😅",
       premium: "Kak, ini fitur premium loh! Biar bisa pake, beli dulu ke owner yaa 😎 (Ketik .owner buat info lebih lanjut)",
   }
}
//========================================\\
global.decor = {
	menut: '❏═┅═━–〈',
	menub: '┊•',
	menub2: '┊',
	menuf: '┗––––––––––✦',
	hiasan: '꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷',

	menut: '––––––『',
    menuh: '』––––––',
    menub: '┊☃︎ ',
    menuf: '┗━═┅═━––––––๑\n',
	menua: '',
	menus: '☃︎',

	htki: '––––––『',
	htka: '』––––––',
	haki: '┅━━━═┅═❏',
	haka: '❏═┅═━━━┅',
	lopr: 'Ⓟ',
	lolm: 'Ⓛ',
	htjava: '❃'
}

//===========================//

global.rpg = {
    emoticon(string) {
        string = string.toLowerCase()
        let emot = {
            level: '📊',
            limit: '🎫',
            health: '❤️',
            exp: '✨',
            atm: '💳',
            money: '💰',
            bank: '🏦',
            potion: '🥤',
            diamond: '💎',
            common: '📦',
            uncommon: '🛍️',
            mythic: '🎁',
            legendary: '🗃️',
            superior: '💼',
            pet: '🔖',
            trash: '🗑',
            armor: '🥼',
            sword: '⚔️',
            makanancentaur: "🥗",
            makanangriffin: "🥙",
            makanankyubi: "🍗",
            makanannaga: "🍖",
            makananpet: "🥩",
            makananphonix: "🧀",
            pickaxe: '⛏️',
            fishingrod: '🎣',
            wood: '🪵',
            rock: '🪨',
            string: '🕸️',
            horse: '🐴',
            cat: '🐱',
            dog: '🐶',
            fox: '🦊',
            robo: '🤖',
            petfood: '🍖',
            iron: '⛓️',
            gold: '🪙',
            emerald: '❇️',
            upgrader: '🧰',
            bibitanggur: '🌱',
            bibitjeruk: '🌿',
            bibitapel: '☘️',
            bibitmangga: '🍀',
            bibitpisang: '🌴',
            anggur: '🍇',
            jeruk: '🍊',
            apel: '🍎',
            mangga: '🥭',
            pisang: '🍌',
            botol: '🍾',
            kardus: '📦',
            kaleng: '🏮',
            plastik: '📜',
            gelas: '🧋',
            chip: '♋',
            umpan: '🪱',
            naga: "🐉",
            phonix: "🦅",
            kyubi: "🦊",
            griffin: "🦒",
            centaur: "🎠",
            skata: '🧩'
        }
        let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
        if (!results.length) return ''
        else return emot[results[0][0]]
    }
}

//===============SETTING MENU==================\\
global.prefix = ['','!','.','#','&']
global.sessionName = 'session'
global.hituet = 0
//media target
global.thum = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.log0 = fs.readFileSync("./data/image/thumb.jpg") //ur logo pic
global.err4r = fs.readFileSync("./data/image/thumb.jpg") //ur error pic
global.thumb = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.defaultpp = 'https://qu.ax/adTpX.jpg?q=60' //default pp wa

//menu image maker
global.flaming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.fluming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=fluffy-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flarun = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=runner-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flasmurf = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='

global.keyopenai = "pk-pIWAlRroXTOAigkWdHcYvmlmgzEQXuoMWbVAaLAVZswSRbEB"
//documents variants
global.doc1 = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
global.doc2 = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
global.doc3 = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
global.doc4 = 'application/zip'
global.doc5 = 'application/pdf'
global.doc6 = 'application/vnd.android.package-archive'

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
